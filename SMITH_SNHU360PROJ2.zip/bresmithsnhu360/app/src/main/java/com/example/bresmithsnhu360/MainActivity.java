package com.example.bresmithsnhu360;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
  private EditText nameText;
  private TextView textGreeting;
  private Button buttonSayHello;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    nameText = findViewById(R.id.nameText);
    textGreeting = findViewById(R.id.textGreeting);
    buttonSayHello = findViewById(R.id.buttonSayHello);
    buttonSayHello.setEnabled(false);

    nameText.addTextChangedListener(new TextWatcher() {
      @Override
      public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

      @Override
      public void onTextChanged(CharSequence s, int start, int before, int count) {}

      @Override
      public void afterTextChanged(Editable s) {
        if (s.toString().isEmpty()) {
          buttonSayHello.setEnabled(false);
        } else {
          buttonSayHello.setEnabled(true);
        }
      }
    });
  }

  public void SayHello(View view) {
    String name = nameText.getText().toString();
    if (name.isEmpty()) {
      textGreeting.setText("You must enter a name");
    } else {
      textGreeting.setText("Hello, " + name + "!");
    }
  }
}

